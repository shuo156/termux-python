#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整 IP 查询服务 - 修复版
已修复CORS和所有已知bug
"""

import argparse
import os
import sys
import json
import sqlite3
import struct
import socket
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

# ====== 配置 ======
DEFAULT_DB = "ipdb.sqlite"
DEFAULT_IP_FILE = "ip.json"
DEFAULT_TRANSLATION_DB = "translation.db"
DEFAULT_TRANSLATION_JSON = "translation.json"
CACHE_SIZE = 2048
MAX_BATCH_QUERY = 100

# ====== HTML 前端（保持原样不变）======
HTML_INDEX = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP 地理查询系统 - 专业版</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --brand-color: #3b82f6;
            --bg-dark: #0f172a;
            --card-bg: rgba(30, 41, 59, 0.7);
        }

        * {
            font-family: 'Noto Sans SC', sans-serif;
            transition: all 0.2s ease-in-out;
        }

        .font-mono {
            font-family: 'JetBrains Mono', monospace;
        }

        body {
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(at 0% 0%, rgba(59, 130, 246, 0.15) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(139, 92, 246, 0.15) 0px, transparent 50%);
            background-attachment: fixed;
            min-height: 100vh;
            color: #f1f5f9;
        }

        .glass-card {
            background: var(--card-bg);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-primary:hover {
            filter: brightness(1.1);
            transform: translateY(-1px);
        }

        .country-icon {
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(59, 130, 246, 0.2);
            border-radius: 12px;
            color: #60a5fa;
            font-size: 1.5rem;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }

        .card-animate {
            animation: fadeIn 0.4s ease-out forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="p-4 md:p-12">

    <div class="max-w-6xl mx-auto space-y-8">
        <nav class="flex flex-col md:flex-row justify-between items-center gap-4">
            <div class="flex items-center space-x-3">
                <i class="fa-solid fa-earth-asia text-3xl text-blue-500"></i>
                <h1 class="text-2xl font-bold tracking-tight">IP <span class="text-blue-500">GEO</span> 查询系统</h1>
            </div>
            <div class="flex items-center space-x-2 text-slate-400 text-sm">
                <span class="px-2 py-1 bg-slate-800 rounded">IPv4</span>
                <span class="px-2 py-1 bg-blue-900/30 text-blue-400 rounded border border-blue-500/20">Real-time</span>
            </div>
        </nav>

        <div class="glass-card rounded-2xl p-6 border-l-4 border-blue-500">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-slate-400 text-sm font-bold uppercase tracking-widest flex items-center">
                    <i class="fa-solid fa-house-signal mr-2"></i> 本地连接信息
                </h2>
                <button onclick="detectMyIP()" class="text-xs text-blue-400 hover:text-blue-300">
                    <i class="fa-solid fa-rotate-right mr-1"></i> 重新检测
                </button>
            </div>
            <div id="my-ip-container">
                <div class="flex items-center space-x-3 text-slate-500">
                    <i class="fa-solid fa-circle-notch animate-spin"></i>
                    <span>正在获取当前环境信息...</span>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-2xl overflow-hidden">
            <div class="flex bg-slate-800/50 border-b border-white/5">
                <button id="tab-single" onclick="switchTab('single')" class="flex-1 py-4 font-bold text-blue-400 border-b-2 border-blue-500">
                    <i class="fa-solid fa-magnifying-glass mr-2"></i>单 IP 查询
                </button>
                <button id="tab-batch" onclick="switchTab('batch')" class="flex-1 py-4 font-medium text-slate-400 hover:text-slate-200">
                    <i class="fa-solid fa-list-check mr-2"></i>批量处理
                </button>
            </div>

            <div class="p-6 md:p-8">
                <div id="panel-single" class="flex flex-col md:flex-row gap-4">
                    <div class="relative flex-1">
                        <i class="fa-solid fa-terminal absolute left-4 top-4 text-slate-500"></i>
                        <input type="text" id="single-ip" placeholder="输入 IPv4 地址..." 
                            class="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3.5 pl-11 pr-4 focus:outline-none focus:border-blue-500 font-mono text-white">
                    </div>
                    <button onclick="querySingle()" class="btn-primary px-8 py-3.5 rounded-xl font-bold">
                        立即检索
                    </button>
                </div>

                <div id="panel-batch" class="hidden space-y-4">
                    <textarea id="batch-ips" rows="5" placeholder="每行输入一个 IP 地址..." 
                        class="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 focus:outline-none focus:border-blue-500 font-mono text-sm text-white"></textarea>
                    <button onclick="queryBatch()" class="btn-primary w-full py-3.5 rounded-xl font-bold">
                        批量解析
                    </button>
                </div>
            </div>
        </div>

        <div id="result-header" class="hidden flex justify-between items-center px-2">
            <h3 class="text-slate-400 font-bold text-sm uppercase"><i class="fa-solid fa-square-poll-vertical mr-2"></i> 查询结果</h3>
            <button onclick="exportJSON()" class="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-md border border-slate-600 transition-colors">
                <i class="fa-solid fa-file-export mr-1"></i> 导出 JSON
            </button>
        </div>

        <div id="loader" class="hidden text-center py-12">
            <i class="fa-solid fa-spinner animate-spin text-3xl text-blue-500"></i>
        </div>
        <div id="results-container" class="grid grid-cols-1 gap-4"></div>
    </div>

<script>
    let lastQueryResults = null;

    function isIPv6(ip) {
        return ip.includes(':');
    }

    function safe(val, fallback = '未知') {
        return val ?? fallback;
    }

    async function detectMyIP() {
        const container = document.getElementById('my-ip-container');
        try {
            const response = await fetch('/api/my-ip');
            const data = await response.json();

            if (!data.success) {
                container.innerHTML = `
                    <p class="text-yellow-400 text-sm">
                        <i class="fa-solid fa-circle-info mr-2"></i>
                        ${data.error || '当前 IP 无法定位（可能是内网或 IPv6）'}
                    </p>
                `;
                return;
            }

            const info = data.data;

            container.innerHTML = `
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center card-animate">
                    <div class="md:col-span-1 flex items-center space-x-4">
                        <div class="country-icon font-bold">
                            ${safe(info.country_code, '<i class="fa-solid fa-earth-asia"></i>')}
                        </div>
                        <div>
                            <p class="text-xs text-slate-500 font-bold uppercase">当前 IP</p>
                            <p class="text-xl font-mono font-bold text-white">${data.query_ip}</p>
                        </div>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-bold mb-1">物理位置</p>
                        <p class="text-white font-medium">
                            ${safe(info.country_zh || info.country)} · ${safe(info.continent_zh || info.continent)}
                        </p>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-bold mb-1">接入运营商</p>
                        <p class="text-white font-medium truncate">
                            ${safe(info.as_name_zh || info.as_name)}
                        </p>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-bold mb-1">自治系统</p>
                        <p class="text-blue-400 font-mono">AS${safe(info.asn, '-')}</p>
                    </div>
                </div>
            `;
        } catch (err) {
            container.innerHTML = `
                <p class="text-red-400">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i>
                    自动检测失败: ${err.message}
                </p>
            `;
            console.error('API Error:', err);
        }
    }

    function switchTab(type) {
        const isSingle = type === 'single';
        document.getElementById('panel-single').classList.toggle('hidden', !isSingle);
        document.getElementById('panel-batch').classList.toggle('hidden', isSingle);

        document.getElementById('tab-single').className =
            isSingle
                ? "flex-1 py-4 font-bold text-blue-400 border-b-2 border-blue-500"
                : "flex-1 py-4 font-medium text-slate-400 hover:text-slate-200";

        document.getElementById('tab-batch').className =
            !isSingle
                ? "flex-1 py-4 font-bold text-blue-400 border-b-2 border-blue-500"
                : "flex-1 py-4 font-medium text-slate-400 hover:text-slate-200";
    }

    function createCard(info, ip) {
        return `
            <div class="glass-card rounded-xl p-6 card-animate">
                <div class="flex flex-col md:flex-row gap-6">
                    <div class="flex-shrink-0 flex flex-col items-center space-y-2">
                        <div class="country-icon">
                            ${safe(info.country_code, '<i class="fa-solid fa-earth-asia"></i>')}
                        </div>
                        <span class="text-[10px] font-bold text-slate-500 uppercase">
                            ${safe(info.continent_zh || info.continent)}
                        </span>
                    </div>
                    <div class="flex-grow grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="col-span-2 md:col-span-1">
                            <label class="text-[10px] text-slate-500 font-bold uppercase">IP</label>
                            <p class="font-mono text-white select-all">${ip}</p>
                        </div>
                        <div>
                            <label class="text-[10px] text-slate-500 font-bold uppercase">国家</label>
                            <p class="text-blue-400 font-bold">
                                ${safe(info.country_zh || info.country)}
                            </p>
                        </div>
                        <div>
                            <label class="text-[10px] text-slate-500 font-bold uppercase">运营商</label>
                            <p class="text-slate-300 truncate">
                                ${safe(info.as_name_zh || info.as_name)}
                            </p>
                        </div>
                        <div>
                            <label class="text-[10px] text-slate-500 font-bold uppercase">ASN / 网段</label>
                            <p class="text-slate-400 text-xs font-mono">
                                AS${safe(info.asn, '-')}<br>${safe(info.network, '-')}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async function querySingle() {
        const ip = document.getElementById('single-ip').value.trim();
        if (!ip) return;

        if (isIPv6(ip)) {
            alert('当前仅支持 IPv4 查询');
            return;
        }

        showLoading(true);
        try {
            const res = await fetch(`/api/query?ip=${encodeURIComponent(ip)}`);
            const data = await res.json();

            if (data.success) {
                lastQueryResults = [data];
                document.getElementById('results-container').innerHTML =
                    createCard(data.data, data.query_ip);
                document.getElementById('result-header').classList.remove('hidden');
            } else {
                document.getElementById('results-container').innerHTML = `
                    <div class="glass-card p-6 rounded-xl text-yellow-400 text-center">
                        <i class="fa-solid fa-circle-info mr-2"></i>
                        ${data.error}
                    </div>
                `;
            }
        } catch (err) {
            alert('请求失败: ' + err.message);
            console.error('Query Error:', err);
        }
        showLoading(false);
    }

    async function queryBatch() {
        const ips = document.getElementById('batch-ips')
            .value.split(/\r?\n/)
            .map(i => i.trim())
            .filter(i => i && !isIPv6(i));

        if (!ips.length) return;

        showLoading(true);
        try {
            const res = await fetch('/api/batch-query', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ips })
            });
            const data = await res.json();

            lastQueryResults = data.results.filter(r => r.success);

            document.getElementById('results-container').innerHTML =
                data.results.map(r =>
                    r.success
                        ? createCard(r.data, r.query_ip)
                        : `<div class="text-yellow-400 text-sm font-mono">
                            ${r.query_ip}：未命中
                           </div>`
                ).join('');

            if (lastQueryResults.length) {
                document.getElementById('result-header').classList.remove('hidden');
            }
        } catch (err) {
            alert('批量查询失败: ' + err.message);
            console.error('Batch Query Error:', err);
        }
        showLoading(false);
    }

    function exportJSON() {
        if (!lastQueryResults?.length) return;
        const blob = new Blob(
            [JSON.stringify(lastQueryResults, null, 2)],
            { type: 'application/json' }
        );
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `ip_query_${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(a.href);
    }

    function showLoading(show) {
        document.getElementById('loader').classList.toggle('hidden', !show);
        if (show) {
            document.getElementById('results-container').innerHTML = '';
            document.getElementById('result-header').classList.add('hidden');
        }
    }

    window.addEventListener('load', detectMyIP);
</script>
</body>
</html>"""

# ====== IP 工具函数 ======
def ip_to_int(ip_str: str) -> int:
    """将 IPv4 IP 转换为整数"""
    try:
        return struct.unpack("!I", socket.inet_aton(ip_str))[0]
    except:
        raise ValueError(f"Invalid IPv4: {ip_str}")

def parse_cidr(cidr: str):
    """解析 CIDR 表示法（仅支持 IPv4）"""
    try:
        base, prefix_s = cidr.split('/')
        prefix = int(prefix_s)
        if prefix < 0 or prefix > 32:
            raise ValueError
        start = ip_to_int(base)
        mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF if prefix < 32 else 0xFFFFFFFF
        start = start & mask
        end = start + (1 << (32 - prefix)) - 1 if prefix < 32 else start
        return start, end
    except Exception as e:
        raise ValueError(f"Invalid CIDR: {cidr}")

# ====== 翻译数据库相关函数 ======
def auto_build_translation_db():
    """自动检测并构建翻译数据库"""
    if os.path.exists(DEFAULT_TRANSLATION_DB):
        print(f"✓ 翻译数据库已存在: {DEFAULT_TRANSLATION_DB}")
        return True
    
    if not os.path.exists(DEFAULT_TRANSLATION_JSON):
        print(f"⚠ 翻译文件 {DEFAULT_TRANSLATION_JSON} 不存在（可选）")
        return False
    
    print(f"🔄 正在从 {DEFAULT_TRANSLATION_JSON} 构建翻译数据库...")
    
    try:
        with open(DEFAULT_TRANSLATION_JSON, 'r', encoding='utf-8') as f:
            trans_dict = json.load(f)
    except Exception as e:
        print(f"✗ JSON 文件格式错误: {e}")
        return False
    
    try:
        conn = sqlite3.connect(DEFAULT_TRANSLATION_DB)
        cur = conn.cursor()
        
        cur.execute("""
            CREATE TABLE translations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original TEXT UNIQUE NOT NULL,
                translated TEXT NOT NULL
            )
        """)
        cur.execute("CREATE INDEX idx_original ON translations(original)")
        
        batch = []
        for original, translated in trans_dict.items():
            batch.append((original, translated))
            
            if len(batch) >= 5000:
                cur.executemany(
                    "INSERT INTO translations (original, translated) VALUES (?,?)",
                    batch
                )
                batch = []
        
        if batch:
            cur.executemany(
                "INSERT INTO translations (original, translated) VALUES (?,?)",
                batch
            )
        
        conn.commit()
        conn.close()
        print(f"✓ 翻译数据库构建完成！导入 {len(trans_dict)} 条翻译")
        return True
    
    except Exception as e:
        print(f"✗ 构建翻译数据库失败: {e}")
        return False

# ====== 数据库构建 ======
def build_database(ip_file: str, db_file: str):
    """从 JSONL 文件构建数据库"""
    print(f"正在从 {ip_file} 构建数据库到 {db_file}...")
    if os.path.exists(db_file):
        os.remove(db_file)
    
    conn = sqlite3.connect(db_file)
    cur = conn.cursor()
    
    cur.execute("""
        CREATE TABLE ip_ranges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_ip INTEGER NOT NULL,
            end_ip INTEGER NOT NULL,
            data TEXT NOT NULL
        )
    """)
    cur.execute("CREATE INDEX idx_start_ip ON ip_ranges(start_ip)")
    cur.execute("CREATE INDEX idx_end_ip ON ip_ranges(end_ip)")
    
    batch = []
    count = 0
    errors = 0
    
    try:
        with open(ip_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                try:
                    obj = json.loads(line)
                    network = obj.get('network', '')
                    
                    if not network:
                        continue
                    
                    try:
                        start_ip, end_ip = parse_cidr(network)
                    except Exception as e:
                        errors += 1
                        if errors <= 10:
                            print(f"[第 {line_num} 行] CIDR 解析失败: {network}")
                        continue
                    
                    data_json = json.dumps(obj, ensure_ascii=False)
                    batch.append((start_ip, end_ip, data_json))
                    
                    if len(batch) >= 5000:
                        cur.executemany(
                            "INSERT INTO ip_ranges (start_ip, end_ip, data) VALUES (?,?,?)",
                            batch
                        )
                        count += len(batch)
                        batch = []
                        print(f"✓ 已处理 {count} 条记录...")
                
                except json.JSONDecodeError:
                    continue
                except Exception as e:
                    continue
        
        if batch:
            cur.executemany(
                "INSERT INTO ip_ranges (start_ip, end_ip, data) VALUES (?,?,?)",
                batch
            )
            count += len(batch)
        
        conn.commit()
        print(f"\n✓ 构建完成！")
        print(f"  成功导入: {count} 条记录")
        print(f"  解析错误: {errors} 条记录")
        return 0
    
    except Exception as e:
        print(f"✗ 构建失败: {e}")
        return 1
    finally:
        conn.close()

# ====== 查询核心 ======
class IPDatabase:
    def __init__(self, db_file: str):
        self.db_file = db_file
        self.trans_cache = {}

    def load_translation(self, original: str) -> str:
        """从翻译数据库查询翻译"""
        if not original:
            return original
        
        if original in self.trans_cache:
            return self.trans_cache[original]
        
        if not os.path.exists(DEFAULT_TRANSLATION_DB):
            return original
        
        try:
            conn = sqlite3.connect(DEFAULT_TRANSLATION_DB)
            cur = conn.cursor()
            cur.execute("SELECT translated FROM translations WHERE original = ? LIMIT 1", (original,))
            row = cur.fetchone()
            conn.close()
            
            if row:
                translated = row[0]
                self.trans_cache[original] = translated
                return translated
            else:
                self.trans_cache[original] = original
                return original
        except:
            return original

    def translate_data(self, data: dict) -> dict:
        """翻译数据中的特定字段"""
        result = dict(data)
        translate_fields = ['country', 'continent', 'as_name']
        
        for field in translate_fields:
            if field in result and result[field]:
                translated = self.load_translation(result[field])
                if translated != result[field]:
                    result[f"{field}_zh"] = translated
        
        return result

    @lru_cache(maxsize=CACHE_SIZE)
    def query_ip_cached(self, ip_str: str):
        """缓存查询结果"""
        try:
            ip_int = ip_to_int(ip_str)
            
            if not os.path.exists(self.db_file):
                return None
            
            conn = sqlite3.connect(self.db_file)
            try:
                cur = conn.cursor()
                cur.execute(
                    "SELECT data FROM ip_ranges WHERE ? >= start_ip AND ? <= end_ip LIMIT 1",
                    (ip_int, ip_int)
                )
                row = cur.fetchone()
                if row:
                    return row[0]
                return None
            finally:
                conn.close()
        except:
            return None

    def query_ip(self, ip_str: str) -> dict:
        """查询单个 IP"""
        res_json = self.query_ip_cached(ip_str)
        if not res_json:
            return {"success": False, "error": "未找到该 IP 的信息", "query_ip": ip_str}
        
        try:
            data = json.loads(res_json)
            data = self.translate_data(data)
            return {"success": True, "query_ip": ip_str, "data": data}
        except:
            return {"success": False, "error": "数据解析失败", "query_ip": ip_str}

# ====== Web Server ======
class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        """自定义日志"""
        sys.stderr.write("[%s] %s - %s\n" % (
            self.log_date_time_string(),
            self.address_string(),
            format % args
        ))
    
    def send_cors_headers(self):
        """发送CORS头"""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
    
    def get_real_ip(self):
        """获取真实IP"""
        if self.headers.get('X-Forwarded-For'):
            return self.headers.get('X-Forwarded-For').split(',')[0].strip()
        if self.headers.get('CF-Connecting-IP'):
            return self.headers.get('CF-Connecting-IP').strip()
        if self.headers.get('X-Real-IP'):
            return self.headers.get('X-Real-IP').strip()
        return self.client_address[0]
    
    def send_json_response(self, data, status=200):
        """发送JSON响应"""
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def do_OPTIONS(self):
        """处理OPTIONS预检"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def do_GET(self):
        """处理GET请求"""
        try:
            parsed = urlparse(self.path)
            
            if parsed.path in ("/", "/index.html"):
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(HTML_INDEX.encode("utf-8"))
                return

            if parsed.path == "/api/my-ip":
                real_ip = self.get_real_ip()
                res = self.server.db.query_ip(real_ip)
                self.send_json_response(res)
                return

            if parsed.path == "/api/query":
                qs = parse_qs(parsed.query)
                ip = qs.get("ip", [""])[0]
                if not ip:
                    self.send_json_response({"success": False, "error": "缺少IP参数"}, 400)
                    return
                res = self.server.db.query_ip(ip)
                self.send_json_response(res)
                return
            
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            
        except Exception as e:
            print(f"GET错误: {e}")
            self.send_json_response({"success": False, "error": f"服务器错误: {str(e)}"}, 500)

    def do_POST(self):
        """处理POST请求"""
        try:
            if self.path == "/api/batch-query":
                length = int(self.headers.get('content-length', 0))
                if length == 0:
                    self.send_json_response({"success": False, "error": "请求体为空"}, 400)
                    return
                
                body_bytes = self.rfile.read(length)
                body = json.loads(body_bytes.decode('utf-8'))
                ips = body.get('ips', [])
                
                if not ips:
                    self.send_json_response({"success": False, "error": "IP列表为空"}, 400)
                    return
                
                results = [self.server.db.query_ip(ip) for ip in ips[:MAX_BATCH_QUERY]]
                self.send_json_response({"results": results})
                return
            
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            
        except json.JSONDecodeError:
            self.send_json_response({"success": False, "error": "JSON格式错误"}, 400)
        except Exception as e:
            print(f"POST错误: {e}")
            self.send_json_response({"success": False, "error": f"服务器错误: {str(e)}"}, 500)

# ====== Main ======
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--build-db", action="store_true", help="构建 IP 数据库")
    p.add_argument("--ip-file", default=DEFAULT_IP_FILE, help="IP 数据文件")
    p.add_argument("--db-file", default=DEFAULT_DB, help="IP 数据库文件")
    p.add_argument("--port", type=int, default=8080, help="服务端口")
    args = p.parse_args()

    if args.build_db:
        return build_database(args.ip_file, args.db_file)

    auto_build_translation_db()

    server = HTTPServer(('0.0.0.0', args.port), Handler)
    server.db = IPDatabase(args.db_file)
    
    print(f"\n{'='*60}")
    print(f"✓ IP查询服务已启动")
    print(f"{'='*60}")
    print(f"  访问地址: http://0.0.0.0:{args.port}")
    print(f"  本地访问: http://localhost:{args.port}")
    print(f"  IP 数据库: {args.db_file} {'✓' if os.path.exists(args.db_file) else '✗ (不存在)'}")
    print(f"  翻译数据库: {DEFAULT_TRANSLATION_DB} {'✓' if os.path.exists(DEFAULT_TRANSLATION_DB) else '- (可选)'}")
    
    if not os.path.exists(args.db_file):
        print(f"\n⚠ 警告：IP 数据库不存在！")
        print(f"  请先运行: python app.py --build-db")
    
    print(f"{'='*60}\n")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n✓ 服务已停止")
        server.shutdown()

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""
IP 地理数据库生成工具（独立版）
将 JSONL 格式的 IP 数据转换为 SQLite 数据库
支持范围查询
"""

import sqlite3
import json
import ipaddress
import os
import sys

def ip_to_int(ip_str):
    """将 IP 地址字符串转换为整数"""
    try:
        return int(ipaddress.IPv4Address(ip_str))
    except:
        return None

def cidr_to_range(network_str):
    """将 CIDR 表示法转换为 IP 范围"""
    try:
        network = ipaddress.IPv4Network(network_str, strict=False)
        start_ip = int(network.network_address)
        end_ip = int(network.broadcast_address)
        return start_ip, end_ip
    except Exception as e:
        raise ValueError(f"CIDR 格式错误: {network_str} - {e}")

def process_ip_file(input_file, output_db, batch_size=500):
    """
    处理 JSONL 文件并生成支持范围查询的 SQLite 数据库
    """
    
    # 创建/连接数据库
    conn = sqlite3.connect(output_db)
    cursor = conn.cursor()
    
    # 删除旧表（如果存在）
    cursor.execute('DROP TABLE IF EXISTS ip_ranges')
    
    # 创建表结构（支持范围查询）
    print("[INFO] 创建表结构...")
    cursor.execute('''
        CREATE TABLE ip_ranges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_ip INTEGER NOT NULL,
            end_ip INTEGER NOT NULL,
            data TEXT NOT NULL
        )
    ''')
    
    # 创建复合索引加速范围查询
    print("[INFO] 创建索引...")
    cursor.execute('CREATE INDEX idx_start_ip ON ip_ranges(start_ip)')
    cursor.execute('CREATE INDEX idx_end_ip ON ip_ranges(end_ip)')
    
    conn.commit()
    
    # 处理数据
    line_count = 0
    success_count = 0
    error_count = 0
    
    print(f"\n[INFO] 开始读取文件: {input_file}\n")
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                try:
                    data = json.loads(line)
                    network = data.get('network', '')
                    
                    if not network:
                        print(f"[WARN] 第 {line_num} 行: 缺少 'network' 字段，跳过")
                        error_count += 1
                        continue
                    
                    # 转换 CIDR 到 IP 范围
                    start_ip, end_ip = cidr_to_range(network)
                    
                    # 存储完整的 JSON 数据
                    data_json = json.dumps(data, ensure_ascii=False)
                    
                    cursor.execute(
                        'INSERT INTO ip_ranges (start_ip, end_ip, data) VALUES (?, ?, ?)',
                        (start_ip, end_ip, data_json)
                    )
                    
                    success_count += 1
                    
                    # 批量提交
                    if success_count % batch_size == 0:
                        conn.commit()
                        print(f"[INFO] ✓ 已处理 {success_count} 条记录...")
                    
                except json.JSONDecodeError as e:
                    print(f"[ERROR] 第 {line_num} 行: JSON 解析失败 - {e}")
                    error_count += 1
                except ValueError as e:
                    print(f"[ERROR] 第 {line_num} 行: {e}")
                    error_count += 1
                except Exception as e:
                    print(f"[ERROR] 第 {line_num} 行: 未知错误 - {e}")
                    error_count += 1
        
        # 最后提交
        conn.commit()
        
        # 优化数据库
        print("[INFO] 正在优化数据库...")
        cursor.execute('VACUUM')
        
    except FileNotFoundError:
        print(f"[ERROR] 文件 {input_file} 不存在！")
        conn.close()
        return False
    except Exception as e:
        print(f"[ERROR] 处理文件时出错: {e}")
        import traceback
        traceback.print_exc()
        conn.close()
        return False
    finally:
        conn.close()
    
    # 打印统计信息
    print("\n" + "="*70)
    print(f"[SUCCESS] ✓ 数据库生成完成！")
    print("="*70)
    print(f"输出文件: {output_db}")
    print(f"成功导入: {success_count} 条 IP 范围记录")
    print(f"失败数量: {error_count} 条记录")
    print(f"数据库大小: {get_db_size(output_db)}")
    print("="*70)
    
    return True

def get_db_size(db_file):
    """获取数据库文件大小（人类可读格式）"""
    try:
        size = os.path.getsize(db_file)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.2f} {unit}"
            size /= 1024
    except:
        return "未知"

def verify_db(db_file):
    """验证数据库完整性和查询功能"""
    print("\n[INFO] 正在验证数据库...\n")
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ip_ranges'")
        if not cursor.fetchone():
            print("[ERROR] 数据库表不存在！")
            return False
        
        # 获取记录数
        cursor.execute("SELECT COUNT(*) FROM ip_ranges")
        count = cursor.fetchone()[0]
        print(f"[INFO] ✓ 数据库中有 {count} 条 IP 范围记录\n")
        
        # 显示前几条记录
        print("[INFO] 数据库样本（前 5 条）：")
        print("-" * 70)
        cursor.execute("SELECT start_ip, end_ip, data FROM ip_ranges LIMIT 5")
        for idx, (start, end, data_json) in enumerate(cursor.fetchall(), 1):
            data = json.loads(data_json)
            print(f"{idx}. 网段: {data.get('network')}")
            print(f"   范围: {start} - {end}")
            print(f"   国家: {data.get('country')} ({data.get('country_code')})")
            if data.get('asn'):
                print(f"   ASN: {data.get('asn')}")
            print()
        
        print("-" * 70)
        
        # 测试范围查询
        print("\n[INFO] 测试范围查询：\n")
        
        # 获取第一条记录做测试
        cursor.execute("SELECT data FROM ip_ranges LIMIT 1")
        row = cursor.fetchone()
        if row:
            data = json.loads(row[0])
            network_str = data.get('network', '')
            if network_str:
                # 取 CIDR 范围的中间值作为测试 IP
                network = ipaddress.IPv4Network(network_str, strict=False)
                test_ip = str(network[1])  # 取第二个 IP
                
                # 测试查询
                test_ip_int = ip_to_int(test_ip)
                cursor.execute(
                    'SELECT data FROM ip_ranges WHERE ? >= start_ip AND ? <= end_ip LIMIT 1',
                    (test_ip_int, test_ip_int)
                )
                result = cursor.fetchone()
                if result:
                    result_data = json.loads(result[0])
                    print(f"✓ 测试 IP: {test_ip}")
                    print(f"  查询结果: {result_data.get('country')} ({result_data.get('network')})")
                else:
                    print(f"✗ 测试 IP: {test_ip} - 查询失败")
        
        conn.close()
        print("\n[SUCCESS] ✓ 数据库验证完成！")
        return True
    except Exception as e:
        print(f"[ERROR] 验证失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='IP 地理数据库生成工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 使用默认文件名
  python build.py
  
  # 指定输入输出文件
  python build.py --input my_data.jsonl --db my_database.db
  
  # 只验证现有数据库
  python build.py --verify-only --db ipdb.sqlite
        '''
    )
    
    parser.add_argument('--input', default='ip.jsonl', help='输入 JSONL 文件（默认: ip.jsonl）')
    parser.add_argument('--db', default='ipdb.sqlite', help='输出数据库文件（默认: ipdb.sqlite）')
    parser.add_argument('--verify-only', action='store_true', help='仅验证现有数据库，不生成')
    
    args = parser.parse_args()
    
    print("\n" + "="*70)
    print("IP 地理数据库生成工具")
    print("="*70)
    
    if args.verify_only:
        # 仅验证模式
        if not os.path.exists(args.db):
            print(f"[ERROR] 数据库文件 {args.db} 不存在！")
            return False
        return verify_db(args.db)
    else:
        # 生成模式
        print(f"输入文件: {args.input}")
        print(f"输出数据库: {args.db}\n")
        
        if not os.path.exists(args.input):
            print(f"[ERROR] 输入文件 {args.input} 不存在！")
            print("[INFO] 请确保 ip.jsonl 在当前目录")
            return False
        
        # 生成数据库
        if process_ip_file(args.input, args.db):
            # 验证数据库
            if verify_db(args.db):
                print("\n[SUCCESS] ✓✓✓ 一切完成！")
                print(f"[INFO] 数据库已准备好用于 API 服务")
                return True
        
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)